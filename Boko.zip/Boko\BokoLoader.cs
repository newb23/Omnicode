﻿using ff14bot.AClasses;
using ff14bot.Helpers;
using ICSharpCode.SharpZipLib.Zip;
using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using Newtonsoft.Json;

namespace BokoLoader
{
    public class BokoLoader : BotPlugin
    {
        // Change these settings to reflect your project!
        private const int ProjectId = 41;

        private const string ProjectName = "Boko";
        private const string ProjectMainType = "Boko.BokoPlugin";
        private const string ProjectAssemblyName = "Boko.dll";
        private static readonly Color LogColor = Color.FromRgb(219, 180, 87);
        public override string Description => "Combat Chocobo Manager";
        public override string Author => "Omninewb";
        public override string ButtonText => "Settings";
        public override Version Version => new Version(0, 0, 3);
        public override bool WantButton => true;

        private static readonly object locker = new object();
        private static readonly string projectAssembly = Path.Combine(Environment.CurrentDirectory, $@"Plugins\{ProjectName}\{ProjectAssemblyName}");
        private static readonly string greyMagicAssembly = Path.Combine(Environment.CurrentDirectory, @"GreyMagic.dll");
        private static readonly string VersionPath = Path.Combine(Environment.CurrentDirectory, $@"Plugins\{ProjectName}\version.txt");
        private static readonly string baseDir = Path.Combine(Environment.CurrentDirectory, $@"Plugins\{ProjectName}");
        private static readonly string projectTypeFolder = Path.Combine(Environment.CurrentDirectory, @"Plugins");
        private static Action onInitialize, onShutdown, onEnabled, onDisabled, onButtonPress, onPulse;
        private static bool updated;

        public object Plugin { get; set; }

        #region Overrides

        public override string Name => ProjectName;

        public override void OnInitialize() => onInitialize?.Invoke();

        public override void OnShutdown() => onShutdown?.Invoke();

        public override void OnEnabled() => onEnabled?.Invoke();

        public override void OnDisabled() => onDisabled?.Invoke();

        public override void OnButtonPress() => onButtonPress?.Invoke();

        public override void OnPulse() => onPulse?.Invoke();

        #endregion Overrides

        public BokoLoader()
        {
            lock (locker)
            {
                if (updated) { return; }
                updated = true;
            }

            Task.Factory.StartNew(AutoUpdate);
        }

        private void Load()
        {
            Log("Loading...");

            RedirectAssembly();

            var assembly = LoadAssembly(projectAssembly);
            if (assembly == null) { return; }

            Type baseType;
            try { baseType = assembly.GetType(ProjectMainType); }
            catch (Exception e)
            {
                Log(e.ToString());
                return;
            }

            try { Plugin = Activator.CreateInstance(baseType); }
            catch (Exception e)
            {
                Log(e.ToString());
                return;
            }

            if (Plugin == null)
            {
                Log("[Error] Could not load main type.");
                return;
            }

            var type = Plugin.GetType();
            onInitialize = (Action)type.GetProperty("OnInitialize").GetValue(Plugin);
            onShutdown = (Action)type.GetProperty("OnShutdown").GetValue(Plugin);
            onEnabled = (Action)type.GetProperty("OnEnabled").GetValue(Plugin);
            onDisabled = (Action)type.GetProperty("OnDisabled").GetValue(Plugin);
            onButtonPress = (Action)type.GetProperty("OnButtonPress").GetValue(Plugin);
            onPulse = (Action)type.GetProperty("OnPulseAction").GetValue(Plugin);

            Log($"{ProjectName} loaded.");
        }

        [DllImport("kernel32", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool DeleteFile(string name);

        public static bool Unblock(string fileName)
        {
            return DeleteFile(fileName + ":Zone.Identifier");
        }

        private static Assembly LoadAssembly(string path)
        {
            if (!File.Exists(path))
            {
                Log($"Could not find Assembly: {path}");
                return null;
            }

            try
            {
                Unblock(path);
            }
            catch (Exception)
            {
                // ignored
            }
            Assembly assembly = null;
            try { assembly = Assembly.LoadFrom(path); }
            catch (Exception e) { Logging.WriteException(e); }

            return assembly;
        }

        private void AutoUpdate()
        {
            var stopwatch = Stopwatch.StartNew();
            var local = GetLocalVersion();

            var message = new VersionMessage { LocalVersion = local, ProductId = ProjectId };
            var responseMessage = GetLatestVersion(message).Result;

            var latest = responseMessage.LatestVersion;

            if (local == latest || latest == null)
            {
                Load();
                return;
            }

            Log($"Updating to version {latest}.");
            var bytes = responseMessage.Data;
            if (bytes == null || bytes.Length == 0) { return; }

            if (!Clean(baseDir))
            {
                Log("Could not clean directory for update.");
                return;
            }

            Log("Extracting new files.");
            if (!Extract(bytes, projectTypeFolder))
            {
                Log("Could not extract new files.");
                return;
            }

            if (File.Exists(VersionPath)) { File.Delete(VersionPath); }
            try { File.WriteAllText(VersionPath, latest); }
            catch (Exception e) { Log(e.ToString()); }

            stopwatch.Stop();
            Log($"Update complete in {stopwatch.ElapsedMilliseconds} ms.");
            Load();
        }

        private static string GetLocalVersion()
        {
            if (!File.Exists(VersionPath)) { return null; }
            try
            {
                return File.ReadAllText(VersionPath);
            }
            catch { return null; }
        }

        private static bool Clean(string directory)
        {
            foreach (var file in new DirectoryInfo(directory).GetFiles())
            {
                try { file.Delete(); }
                catch { return false; }
            }

            foreach (var dir in new DirectoryInfo(directory).GetDirectories())
            {
                try { dir.Delete(true); }
                catch { return false; }
            }

            return true;
        }

        private static bool Extract(byte[] files, string directory)
        {
            using (var stream = new MemoryStream(files))
            {
                var zip = new FastZip();

                try { zip.ExtractZip(stream, directory, FastZip.Overwrite.Always, null, null, null, false, true); }
                catch (Exception e)
                {
                    Log(e.ToString());
                    return false;
                }
            }

            return true;
        }

        private static async Task<VersionMessage> GetLatestVersion(VersionMessage message)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://api.omniverse.tech");

                var json = JsonConvert.SerializeObject(message);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response;
                try
                {
                    response = await client.PostAsync("/api/products/version", content);
                }
                catch (Exception e)
                {
                    Log(e.Message);
                    return null;
                }

                var contents = await response.Content.ReadAsStringAsync();
                var responseObject = JsonConvert.DeserializeObject<VersionMessage>(contents);
                return responseObject;
            }
        }

        private static void Log(string message)
        {
            Logging.Write(LogColor, $"[Auto-Updater][{ProjectName}] {message}");
        }

        public static void RedirectAssembly()
        {
            ResolveEventHandler handler = (sender, args) =>
            {
                var name = Assembly.GetEntryAssembly().GetName().Name;
                var requestedAssembly = new AssemblyName(args.Name);
                return requestedAssembly.Name != name ? null : Assembly.GetEntryAssembly();
            };

            AppDomain.CurrentDomain.AssemblyResolve += handler;

            ResolveEventHandler greyMagicHandler = (sender, args) =>
            {
                var requestedAssembly = new AssemblyName(args.Name);
                return requestedAssembly.Name != "GreyMagic" ? null : Assembly.LoadFrom(greyMagicAssembly);
            };

            AppDomain.CurrentDomain.AssemblyResolve += greyMagicHandler;
        }

        private class VersionMessage
        {
            public int ProductId { get; set; }
            public string LocalVersion { get; set; }
            public string LatestVersion { get; set; }
            public byte[] Data { get; set; } = new byte[0];
        }
    }
}